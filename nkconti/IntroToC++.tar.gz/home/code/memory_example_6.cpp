#include <iostream>
using std::cout;

void AddOne(int* j) {
    // Dereference the pointer and increment the int being pointed to.
    (*j)++;
}

int main() {
    int i = 1;
    cout << "The value of i is: " << i << "\n";
    
    // Declare a pointer to i:
    int* pi = &i;
    AddOne(pi);
    cout << "The value of i is now: " << i << "\n";
}
