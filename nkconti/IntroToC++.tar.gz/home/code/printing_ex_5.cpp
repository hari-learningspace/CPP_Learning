#include <iostream>
#include <vector>
using std::vector;
using std::cout;

int main() {

    vector<vector<int>> b = {{1, 1, 2, 3},
                             {2, 1, 2, 3},
                             {3, 1, 2, 3}};
    cout << b.size() << std::endl;
    // Print the length of an inner vector of b here.
    cout << b[1].size() << std::endl;

}
