#include <iostream>
using std::cout;

int main() {
    cout << "Hello!" << "\n";   
}
