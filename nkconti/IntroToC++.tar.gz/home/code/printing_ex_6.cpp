#include <iostream>
#include <vector>
using std::vector;
using std::cout;

int main() {
    for (int i=0; i < 5; i++) {
      cout << i << "\n";
    }
}
