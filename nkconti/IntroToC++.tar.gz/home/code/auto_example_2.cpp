#include <iostream>
#include <vector>
using std::vector;
using std::cout;

int main() {
    // Declare and initialize v using auto here.
    auto v_7{7, 8, 9, 10}; // gives compilation error -  direct-list-initialization of ‘auto’ requires exactly one element
    //auto v_7 = {7, 8, 9, 10};
    for(auto i : v_7)
        cout << i << " ";
    cout << "\n";
}
