// Example solution for Rectangle and Square friend classes
#include <assert.h>


// Define class Square as friend of Rectangle
class Square{
    public:
    // Add public constructor to Square, initialize side
    Square(int side):side_(side){}
    // Add friend class Rectangle
    friend class Rectangle;
    // Add private attribute side
    private:
    int side_;
};
   
// Declare class Rectangle
class Rectangle{
    public:
    Rectangle(Square square);
    int Area();
    private:
    int width_;
    int height_;    
};
// Define class Rectangle
    // Add public function to Rectangle: Area()
    
    // Add private attributes width, height;

// Define a Rectangle constructor that takes a Square
    Rectangle::Rectangle(Square square){
        width_ = height_ = square.side_; // possible because Rect is friend
    }
// Define Area() to compute area of Rectangle
    int Rectangle::Area(){
        return width_ * height_;        
    }

// Update main() to pass the tests
int main()
{
    Square square(4);
    Rectangle rectangle(square);
    assert(rectangle.Area() == 16); 
}
