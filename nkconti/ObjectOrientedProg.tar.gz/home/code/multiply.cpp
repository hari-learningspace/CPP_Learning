#include <cassert>
#include <cmath>
#include <stdexcept>

// TODO: Define class Sphere
class Sphere {
 public:
  // Constructor
    Sphere(int radius):radius_(radius){
       // validate();
    }

  // Accessors
    int Radius() const{
        return radius_;
    }
    
    float Volume() const{
        return ((4 * 22 * radius_*radius_*radius_)/(3 * 7));
    }
    
 private:
  // Private members
    int radius_;
};

// Test
int main(void) {
  Sphere sphere(5);
  assert(sphere.Radius() == 5);
  assert(abs(sphere.Volume() - 523.6) < 1);
}
