// include iostream for printing

// Define Point class

    // Declare private attributes x and y

    // Define public constructor
    // Define operator overload
    // Define print() function
    // Overload print() function to take 1 or 2 input params
    
// Test in main()

