#include <iostream>
#include <string>

class BankAccount
{
  private:
      // TODO: declare member variables
    int accountNumber_;
    std::string name_;
    float balance_;

  public:
    BankAccount(std::string Name, int AccountNumber, float Balance);
      // TODO: declare setters
    void name(std::string name);
    void accountNumber(int);       
    void balance(float balance);  

      // TODO: declare getters
    std::string name() const;
    int accountNumber() const;
    float balance() const;
};

BankAccount::BankAccount(std::string name_, int accountNumber_, float balance_){
    name(name_);
    accountNumber(accountNumber_);
    balance(balance_);
}


// TODO: implement setters
void BankAccount::name(std::string name)
{
    BankAccount::name_ = name;
}
void BankAccount::accountNumber(int AccNo){
    BankAccount::accountNumber_ = AccNo;
}

void BankAccount::balance(float balance){
    BankAccount::balance_ = balance;
}

// TODO: implement getters
std::string BankAccount::name() const{
    return BankAccount::name_;
}
int BankAccount::accountNumber() const{
    return BankAccount::accountNumber_;
}
float BankAccount::balance() const{
    return BankAccount::balance_;
}

int main(){
    // TODO: instantiate and output a bank account
    BankAccount acc1("Nishin",12345,80000.00);
    
    std::cout<<acc1.name()<<"\n";
    std::cout<<"Acc No: "<<acc1.accountNumber()<<"\n";
    std::cout<<"Balance: "<<acc1.balance()<<"\n";
    
}
