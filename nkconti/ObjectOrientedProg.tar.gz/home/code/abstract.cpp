// Include iostream for printing
// Define Abstraction class
    // Define private attributes
    // Define public setter and printing functions
    
        
// Test in main()

