// include iostream for printing

// Define class Base

    // Declare an empty public constructor
    // Define virtual print() function
    // Define non-virtual calc() function

// Define subclass Derived that publicly inherits from Base

    // Declare an empty public constructor
    // Define print() function
    // Define calc() function

// Test in main()

