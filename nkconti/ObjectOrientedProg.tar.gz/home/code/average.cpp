#include <iostream>

// Define template for average() function

// Test in main() with different data types
int main()
{

}
