#include <assert.h>
#include <iostream>
// TODO: Create a generic function Product that multiplies two parameters
template <typename T>
T Product(T a, T b) {
    return a * b;
}

class Ax{
    public:
    Ax(int x) : x(x) {}
    int x;
}

int main() { 
  assert(Product<int>(10, 2) == 20); 
    /* Ax A(10);
    Ax B(2);
    std::cout << Product<Ax>(A, B); */ //wont compile since * is not overloaded
}
