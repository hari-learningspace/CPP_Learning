#include <assert.h>
#include <iostream>
#include <string>

struct Person {
public:
  // TODO: Add an initialization list
//References used as function parameters can also be const. 
//This allows us to access the argument without making a copy of it, 
//while guaranteeing that the function will not change the value being referenced.
// need to put the const since the reference should also be a const    
  Person(std::string const &name) : name(name) {
      //Person::name = name;
  }
  std::string const name;
};

// Test
int main() {
    enum class human {ktall, short, klean};
    std::string s{"Nishin"};// here Nishin will be stored in a memory x
    // when we pass s below 
    std::cout << &s <<"\n";
  Person alice(s);
    s = "Bob";
  Person bob("Bob");
    
    std::cout << alice.name <<"\n";
    std::cout << &alice.name <<"\n";
    std::cout << &s <<"\n";
  assert(alice.name != bob.name);
}
